from django.apps import AppConfig


class AccmanageConfig(AppConfig):
    name = 'accmanage'
