from django.apps import AppConfig


class RoommanageConfig(AppConfig):
    name = 'roommanage'
